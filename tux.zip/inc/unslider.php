<script src="//unslider.com/unslider.js"></script>
<div class="unslider">
    <ul>
        <li><img src="http://img.zcool.cn/community/01f7515548d5460000019ae939499e.jpg" alt="" ></li>
        <li><img src="http://img.zcool.cn/community/0172d75548db530000019ae97afbbb.jpg" alt="" ></li>
        <li><img src="http://img.zcool.cn/community/01b0f25577f21e00000059ff918e35.jpg" alt="" ></li>
    </ul>
</div>
<script>$(function() { $('.unslider').unslider({
	speed: 500,               //  The speed to animate each slide (in milliseconds)
	delay: 3000,              //  The delay between slide animations (in milliseconds)
	complete: function() {},  //  A function that gets called after every slide animation
	keys: true,               //  Enable keyboard (left, right) arrow shortcuts
	dots: true,               //  Display dot navigation
	fluid: false              //  Support responsive design. May break non-responsive designs
}) })</script>

